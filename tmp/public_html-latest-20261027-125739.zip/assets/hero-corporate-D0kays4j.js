const o="/assets/hero-corporate-CnwhMT63.jpg";export{o as h};
