const t="/assets/helmet-manufacturing-BgCpGqX1.jpg";export{t as h};
