const a="/assets/about-hero-sri-lanka-v3-CJ7HHG2t.jpg";export{a as h};
