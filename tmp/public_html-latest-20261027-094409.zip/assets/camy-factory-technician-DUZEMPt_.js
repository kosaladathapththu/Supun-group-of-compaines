const e="/assets/camy-factory-technician-BW6IuRv3.jpg";export{e};
